from flask import Flask, request, jsonify
import pickle
import numpy as np


app = Flask(__name__)

__model = None
__columns = None

def load_data():
    global __model
    if __model is None:
        with open("heart.pickle","rb") as f:
            __model = pickle.load(f)
    print(__model)
    print("Data imported")

def predict_disease(data):
    data = np.asarray(data)
    print(data.shape)
    data = np.reshape(data,newshape=(1,13))
    print(data.shape)
    return round(__model.predict(data)[0])

@app.route('/hello')
def hello():
    return "HI"


@app.route('/get_prediction', methods=['POST', 'GET'])
def get_prediction():
    data = request.form.getlist("data[]")
    data = list(map(int, data))
    print(data)
    answer = predict_disease(data)
    if answer == 0:
        print("You do not have a disease")
    else:
        print("You have a disease")
    response = jsonify({'answer':answer})
    response.headers.add('Access-Control-Allow-Origin','*')
    return response



if __name__ == "__main__":
    print("Starting Python Flask server for Heart Disease Prediction......")
    load_data()
    app.run()

