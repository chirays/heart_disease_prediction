function onClickGetPrediction() {
    console.log("Inside the get prediction fuccntion in JS");
    var data = [];
    data[0] = document.getElementById("age").value;
    data[1] = document.getElementById("sex").value;
    data[2] = document.getElementById("cp").value;
    data[3] = document.getElementById("trestbps").value;
    data[4] = document.getElementById("chol").value;
    data[5] = document.getElementById("fbs").value;
    data[6] = document.getElementById("restecg").value;
    data[7] = document.getElementById("mhra").value;
    data[8] = document.getElementById("exang").value;
    data[9] = document.getElementById("std").value;
    data[10] = document.getElementById("slope").value;
    data[11] = document.getElementById("flour").value;
    data[12] = document.getElementById("thal").value;
    console.log(data);

    var predres = document.getElementById("predictedresult");
    //var url = "http://127.0.0.1:5000/get_prediction";
    var url = "/api/get_prediction";
    $.post(url, {
        "data": data
    }, function (data, status) {
        console.log(data.answer);
        if (data.answer == 0) {

            predres.innerHTML = "According to analysis, 'YOU DO NOT HAVE A HEART DISEASE'";
            console.log(status);
        }
        else {

            predres.innerHTML = "According to analysis, 'YOU HAVE A HEART DISEASE'";
            console.log(status);
        }
    })


}